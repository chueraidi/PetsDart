package com.example.finalwork

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val username = findViewById<EditText>(R.id.username3)
        val pass_word = findViewById<EditText>(R.id.password3)
        val Login = findViewById<Button>(R.id.button3)

        Login.setOnClickListener {
            val database = FirebaseFirestore.getInstance()
            val docRef = database.collection("user").document(username.text.toString())
                .get().addOnSuccessListener { result ->

                    if (result.exists()){

                        val data = result.data
                        val  password = data?.get("password") as String
                        if (password.equals(pass_word.text.toString())){
                            Toast.makeText(this,"Correct!!",Toast.LENGTH_SHORT).show()
                        }
                        else {
                            Toast.makeText(this,"Wrong!!",Toast.LENGTH_SHORT).show()
                        }
                    }
                    else {
                        Toast.makeText(this,"Wrong!!",Toast.LENGTH_SHORT).show()
                    }

                }
        }
    }
}