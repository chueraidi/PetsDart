package com.example.finalwork

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val username = findViewById<EditText>(R.id.username1)
        val pass_word = findViewById<EditText>(R.id.password1)
        val Login = findViewById<Button>(R.id.login2)

        Login.setOnClickListener {

            val database = Firebase.database
            val docRef = database.getReference("users").child(username.text.toString())

            docRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()){
                        val data = snapshot.value as HashMap<String,String>
                        val password = data["password"]
                        if (password.equals(pass_word.text.toString())){
                            Toast.makeText(this@MainActivity2,"Correct!!",Toast.LENGTH_SHORT).show()
                        }
                        else{
                            Toast.makeText(this@MainActivity2,"Wrong!!",Toast.LENGTH_SHORT).show()
                        }
                    }
                    else{
                        Toast.makeText(this@MainActivity2,"Wrong!!",Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })

        }

    }
}