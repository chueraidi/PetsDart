package com.example.finalwork

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.ktx.database
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        val s_id = findViewById<EditText>(R.id.student_id)
        val firstname = findViewById<EditText>(R.id.first_name)
        val lastname = findViewById<EditText>(R.id.last_name)
        val save = findViewById<Button>(R.id.save)
        val readFS = findViewById<Button>(R.id.read)
        val readDB = findViewById<Button>(R.id.button)

        readDB.setOnClickListener {
            val to_go_read = Intent(this,MainActivity2::class.java)
            startActivity(to_go_read)
        }


        readFS.setOnClickListener {
            val go_to_read = Intent (this,MainActivity3::class.java)
            startActivity(go_to_read)
        }

        save.setOnClickListener {
            val db = Firebase.firestore

            val user = hashMapOf(
                "password" to password.text.toString(),
                "firstname" to firstname.text.toString(),
                "lastname" to lastname.text.toString(),
                "s_id" to s_id.text.toString()
            )

            db.collection("user").document(username.text.toString()).set(user)
                .addOnSuccessListener {
                    Toast.makeText(this,"Data Save",Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show()
                }


//
//            val database = Firebase.database
//            val myRef = database.getReference("users").child(username.text.toString())
//
//            val users = hashMapOf(
//                "password" to password.text.toString(),
//                "firstname" to firstname.text.toString(),
//                "lastname" to lastname.text.toString(),
//                "s_id" to s_id.text.toString()
//            )
//
//            myRef.setValue(users)
        }
    }
}

